package mekegema; 
                  
public enum ID {  
	              
	Player(),     
	BasicEnemy(), 
	Trail();      
                  
}                 
